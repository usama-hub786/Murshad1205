// Configuration for Murshad MD 💀 bot
module.exports = {
  ownerName: 'Usama',
  botName: 'Murshad MD 💀',
  creatorName: 'Jani',
  groupLink: 'https://chat.whatsapp.com/LCtKmwcOP3JHi7E4TeR90j?mode=ac_c'
};