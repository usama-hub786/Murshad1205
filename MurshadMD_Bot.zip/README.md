# Murshad MD 💀

A powerful WhatsApp MD bot built for Usama by Jani.